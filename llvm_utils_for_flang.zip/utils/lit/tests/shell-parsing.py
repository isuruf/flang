# Just run the ShUtil unit tests.
#
# RUN: %{python} -m lit.ShUtil
