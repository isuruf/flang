#!/bin/sh

echo "a line with bad encoding: �."
